Barebones services and drivers meant to play games only.
You can't install any drivers, application or make changes on Windows while on barebone services.
Please revert to default services and drivers whenever you want to make a change on operating system.

PLEASE RUN STATIC IP SCRIPT FIRST, THEN DISABLE STATIC IP SERVICES

Thank you for choosing XOS, enjoy pure gaming.
---
name: Defender Remover Issue Report
about: Describe the problem there
title: ''
labels: ''
assignees: ''

---

## *What* affects the bug ?
<!-- Ex. Microsoft Store, Windows Explorer, Windows Defender Security App. -->

## *When* does this occur?
<!-- Ex. Steps of reproduce of the issue if that can be reproducble.-->

## *In which* version of Windows does this issue happen ? Write version complete.
<!-- Ex. Windows 10 LTSB 1809 17763.3312 or Windows 11 21H2, name of editions are optional -->


## *How* do we replicate the issue?
<!-- Please be specific as possible. Use dashes (-) or numbers (1.) to create a list of steps -->


## Expected behavior (if you have any solution write here.)
<!-- What should have happened? -->


## Other Comments
